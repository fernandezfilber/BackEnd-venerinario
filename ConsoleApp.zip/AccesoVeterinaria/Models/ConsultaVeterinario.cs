﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Models
{
    public class ConsultaVeterinario
    {
        public int Id { get; set; }
        public DateOnly? FechaConsulta { get; set; }
        public String Motivo { get; set; }
        public String NombreMascota { get; set; }
        public String Enfermedad { get; set; }
        public String Tratamiento { get; set; }
        public String Observaciones { get; set; }
    }
}
