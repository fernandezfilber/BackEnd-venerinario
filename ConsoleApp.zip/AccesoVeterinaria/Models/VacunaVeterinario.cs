﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Models
{
   
        public class VacunaVeterinario
        {
            public int IdVacuna { get; set; }
            public string NombreVacuna { get; set; }
            public DateOnly? FechaAplicacion { get; set; }
            public string ProximaDosis { get; set; }

            public int IdMascota { get; set; }
            public string NombreMascota { get; set; }
            public string Especie { get; set; }               // mascota.especie
            public string Raza { get; set; }                   // mascota.raza
            public int? Edad { get; set; }


        }
    
}
