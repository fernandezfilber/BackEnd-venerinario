﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace AccesoVeterinaria.Models;

public partial class Mascotum
{
    public int IdMascota { get; set; }

    public string? Nombre { get; set; }

    public string? Especie { get; set; }

    public string? Raza { get; set; }

    public int? Edad { get; set; }

    public string? Sexo { get; set; }

    public int? IdDueño { get; set; }

    [JsonIgnore]
    public virtual ICollection<Consultum> Consulta { get; set; } = new List<Consultum>();
    [JsonIgnore]
    public virtual ICollection<HistorialMedico> HistorialMedicos { get; set; } = new List<HistorialMedico>();
    
    public virtual Dueño? IdDueñoNavigation { get; set; }
    [JsonIgnore]
    public virtual ICollection<Vacuna> Vacunas { get; set; } = new List<Vacuna>();
}
