﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace AccesoVeterinaria.Models;

public partial class Dueño
{
    public int IdDueño { get; set; }

    public string? Nombre { get; set; }

    public string? Telefono { get; set; }

    public string? Direccion { get; set; }

    public string? Correo { get; set; }

    [JsonIgnore]
   public virtual ICollection<Mascotum> Mascota { get; set; } = new List<Mascotum>();
}
