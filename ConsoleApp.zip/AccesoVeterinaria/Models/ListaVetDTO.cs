﻿namespace Web_Api.DTOs
{
    public class ListaVetDTO
    {
        public string Usuario { get; set; } = string.Empty!;

     

        public string Nombre { get; set; } = string.Empty!;

        public string Telefono { get; set; } = string.Empty!;

        public string Correo { get; set; } = string.Empty!;

        public bool? Activo { get; set; }
    }
}
