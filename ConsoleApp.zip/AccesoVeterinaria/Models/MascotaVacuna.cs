﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Models
{
    public class MascotaVacuna
    {
        public string NombreMascota { get; set; }
        public string Especie { get; set; }
        public string NombreVacuna { get; set; }
        public DateOnly FechaAplicacion { get; set; }
        public string ProximaDosis { get; set; }
    }

}
