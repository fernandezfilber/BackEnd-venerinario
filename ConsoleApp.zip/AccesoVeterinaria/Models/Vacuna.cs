﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace AccesoVeterinaria.Models;

public partial class Vacuna
{
    public int IdVacunas { get; set; }

    public string? NombreVacuna { get; set; }

    public DateOnly FechaAplicacion { get; set; }

    public string ProximaDosis { get; set; }

    public int? IdMascota { get; set; }

    [JsonIgnore]


    public virtual Mascotum? IdMascotaNavigation { get; set; }
}
