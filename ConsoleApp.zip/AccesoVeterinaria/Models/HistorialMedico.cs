﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace AccesoVeterinaria.Models;

public partial class HistorialMedico
{
    public int IdHistorialMedico { get; set; }

    public int? IdEnfermedad { get; set; }

    public int? IdMascota { get; set; }

    [JsonIgnore]
    public virtual Enfermedad? IdEnfermedadNavigation { get; set; }
    [JsonIgnore]
    public virtual Mascotum? IdMascotaNavigation { get; set; }
}
