﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace AccesoVeterinaria.Models;

public partial class Enfermedad
{
    public int IdEnfermedad { get; set; }

    public string? Nombre { get; set; }

    public string? Descripcion { get; set; }

    [JsonIgnore]

    public virtual ICollection<HistorialMedico> HistorialMedicos { get; set; } = new List<HistorialMedico>();
}
