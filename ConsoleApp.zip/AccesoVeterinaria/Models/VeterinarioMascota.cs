﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Models
{
    public class VeterinarioMascota
        {
            public string NombreVetirinario { get; set; }
            public string NombreMascota { get; set; }
        }
    
}
