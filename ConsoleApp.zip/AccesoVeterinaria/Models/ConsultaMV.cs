﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Models
{
    public class ConsultaMV
    {
        public string detalleConsulta { get; set; }     // Viene de Mascota.nombre
        public string nombreMascota { get; set; }             // Viene de Consulta.motivo
        public string nombreVeterinario { get; set; }        // Viene de Consulta.tratamiento
       
    }
}
