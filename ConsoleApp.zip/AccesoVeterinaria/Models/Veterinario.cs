﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace AccesoVeterinaria.Models;

public partial class Veterinario
{
    public int   IdVeterinario { get; set; }

    public string Usuario { get; set; } = null!;

    public string Contrasena { get; set; } = null!;

    public string Nombre { get; set; }

    public string Telefono { get; set; }

    public string Correo { get; set; }

    public bool Activo { get; set; } // NULLABLE
    [Column("RoleId")] // Esto le dice a EF Core que la columna en la DB se llama 'RoleId'
    
    public RolUsuario? Rol { get; set; }

    public virtual ICollection<Consultum> Consulta { get; set; } = new List<Consultum>();
}
