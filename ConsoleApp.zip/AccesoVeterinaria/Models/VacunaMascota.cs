﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Models
{

    public class VacunaMascota
    {
        public string NombreVacuna { get; set; }
        public string NombreMascota { get; set; }
    }
}
