﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Models
{
    public class HIstorialCompletoMV
    {
        public string NombreMascota { get; set; }
        public int? IdHistorialMedico { get; set; }
        public int? IdMascota { get; set; }
        public string NombreEnfermedad { get; set; }
        public string DescripcionEnfermedad { get; set; }
        public string NombreVacuna { get; set; }
        public DateOnly? FechaAplicacionVacuna { get; set; }
        public string ProximaDosisVacuna { get; set; }
    }
}
