﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace AccesoVeterinaria.Models;

public partial class Consultum
{
    public int IdConsultas { get; set; }

    public DateOnly? FechaConsulta { get; set; }

    public string? Motivo { get; set; }

    public string? Tratamiento { get; set; }

    public string? Observaciones { get; set; }

    public int IdMascota { get; set; }

    public int IdVeterinario { get; set; }

    [JsonIgnore]

    public virtual Mascotum? IdMascotaNavigation { get; set; }

    [JsonIgnore]


    public virtual Veterinario? IdVeterinarioNavigation { get; set; }
}
