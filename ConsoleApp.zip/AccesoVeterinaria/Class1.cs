﻿namespace AccesoVeterinaria
{
    public class Class1
    {

    }
}
