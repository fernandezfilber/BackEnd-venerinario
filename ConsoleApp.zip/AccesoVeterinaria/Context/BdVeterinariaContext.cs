﻿using System;
using System.Collections.Generic;
using AccesoVeterinaria.Models;
using Microsoft.EntityFrameworkCore;

namespace AccesoVeterinaria.Context;

public partial class BdVeterinariaContext : DbContext
{
    public BdVeterinariaContext()
    {
    }

    public BdVeterinariaContext(DbContextOptions<BdVeterinariaContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Consultum> Consulta { get; set; }

    public virtual DbSet<Dueño> Dueños { get; set; }

    public virtual DbSet<Enfermedad> Enfermedads { get; set; }

    public virtual DbSet<HistorialMedico> HistorialMedicos { get; set; }

    public virtual DbSet<Mascotum> Mascota { get; set; }

    public virtual DbSet<Vacuna> Vacunas { get; set; }

    public virtual DbSet<Veterinario> Veterinarios { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=FILBER-FERNANDE\\SQLEXPRESS;Database=BD_VETERINARIA;TrustServerCertificate=True;User Id=userM;Password=60635681" + ";MultipleActiveResultSets=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Consultum>(entity =>
        {
            entity.HasKey(e => e.IdConsultas).HasName("PK__consulta__CE576F5EDF568F46");

            entity.ToTable("consulta");

            entity.Property(e => e.IdConsultas).HasColumnName("id_consultas");
            entity.Property(e => e.FechaConsulta).HasColumnName("fecha_consulta");
            entity.Property(e => e.IdMascota).HasColumnName("id_mascota");
            entity.Property(e => e.IdVeterinario).HasColumnName("id_veterinario");
            entity.Property(e => e.Motivo)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("motivo");
            entity.Property(e => e.Observaciones)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("observaciones");
            entity.Property(e => e.Tratamiento)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("tratamiento");

            entity.HasOne(d => d.IdMascotaNavigation).WithMany(p => p.Consulta)
                .HasForeignKey(d => d.IdMascota)
                .HasConstraintName("FK__consulta__id_mas__4222D4EF");

            entity.HasOne(d => d.IdVeterinarioNavigation).WithMany(p => p.Consulta)
                .HasForeignKey(d => d.IdVeterinario)
                .HasConstraintName("FK__consulta__id_vet__4316F928");
        });

        modelBuilder.Entity<Dueño>(entity =>
        {
            entity.HasKey(e => e.IdDueño).HasName("PK__dueño__3C7AED5BD6852EFC");

            entity.ToTable("dueño");

            entity.Property(e => e.IdDueño).HasColumnName("id_dueño");
            entity.Property(e => e.Correo)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("correo");
            entity.Property(e => e.Direccion)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("direccion");
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombre");
            entity.Property(e => e.Telefono)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("telefono");
        });

        modelBuilder.Entity<Enfermedad>(entity =>
        {
            entity.HasKey(e => e.IdEnfermedad).HasName("PK__enfermed__D027B3A0BB146F8E");

            entity.ToTable("enfermedad");

            entity.Property(e => e.IdEnfermedad).HasColumnName("id_enfermedad");
            entity.Property(e => e.Descripcion)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("descripcion");
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombre");
        });

        modelBuilder.Entity<HistorialMedico>(entity =>
        {
            entity.HasKey(e => e.IdHistorialMedico).HasName("PK__historia__FA1C6207212C2137");

            entity.ToTable("historial_medico");

            entity.Property(e => e.IdHistorialMedico).HasColumnName("id_historial_medico");
            entity.Property(e => e.IdEnfermedad).HasColumnName("id_enfermedad");
            entity.Property(e => e.IdMascota).HasColumnName("id_mascota");

            entity.HasOne(d => d.IdEnfermedadNavigation).WithMany(p => p.HistorialMedicos)
                .HasForeignKey(d => d.IdEnfermedad)
                .HasConstraintName("FK__historial__id_en__48CFD27E");

            entity.HasOne(d => d.IdMascotaNavigation).WithMany(p => p.HistorialMedicos)
                .HasForeignKey(d => d.IdMascota)
                .HasConstraintName("FK__historial__id_ma__49C3F6B7");
        });

        modelBuilder.Entity<Mascotum>(entity =>
        {
            entity.HasKey(e => e.IdMascota).HasName("PK__mascota__6F037352500B1D1E");

            entity.ToTable("mascota");

            entity.Property(e => e.IdMascota).HasColumnName("id_mascota");
            entity.Property(e => e.Edad).HasColumnName("edad");
            entity.Property(e => e.Especie)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("especie");
            entity.Property(e => e.IdDueño).HasColumnName("id_dueño");
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombre");
            entity.Property(e => e.Raza)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("raza");
            entity.Property(e => e.Sexo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("sexo");

            entity.HasOne(d => d.IdDueñoNavigation).WithMany(p => p.Mascota)
                .HasForeignKey(d => d.IdDueño)
                .HasConstraintName("FK__mascota__id_dueñ__398D8EEE");
        });

        modelBuilder.Entity<Vacuna>(entity =>
        {
            entity.HasKey(e => e.IdVacunas).HasName("PK__vacuna__60CB9D2E6EB52130");

            entity.ToTable("vacuna");

            entity.Property(e => e.IdVacunas).HasColumnName("id_vacunas");
            entity.Property(e => e.FechaAplicacion).HasColumnName("fecha_aplicacion");
            entity.Property(e => e.IdMascota).HasColumnName("id_mascota");
            entity.Property(e => e.NombreVacuna)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombre_vacuna");
            entity.Property(e => e.ProximaDosis)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("proxima_dosis");

            entity.HasOne(d => d.IdMascotaNavigation).WithMany(p => p.Vacunas)
                .HasForeignKey(d => d.IdMascota)
                .HasConstraintName("FK__vacuna__id_masco__45F365D3");
        });

        modelBuilder.Entity<Veterinario>(entity =>
        {
            entity.HasKey(e => e.IdVeterinario).HasName("PK__veterina__16E06DFFF0168ADD");

            entity.ToTable("veterinario");

            entity.HasIndex(e => e.Usuario, "UQ__veterina__9AFF8FC6C1C20990").IsUnique();

            entity.Property(e => e.IdVeterinario).HasColumnName("id_veterinario");
            entity.Property(e => e.Activo)
                .HasDefaultValue(true)
                .HasColumnName("activo");
            entity.Property(e => e.Contrasena)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("contrasena");
            entity.Property(e => e.Correo)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("correo");
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombre");
            entity.Property(e => e.Telefono)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("telefono");
            entity.Property(e => e.Usuario)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("usuario");
            // **AQUÍ ES DONDE AÑADES LA CONFIGURACIÓN PARA LA PROPIEDAD ROL**
            entity.Property(e => e.Rol) // Suponiendo que la propiedad en tu clase se llama 'Rol'
                .HasMaxLength(50) // Define una longitud máxima adecuada para los nombres de rol
                .IsUnicode(false) // Si tus roles son ASCII (ej. "admin", "operador")
                .HasColumnName("RoleId");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
