﻿using AccesoVeterinaria.Context; // Asegúrate de que esta ruta sea correcta para tu DbContext
using AccesoVeterinaria.Models;
using AccesoVeterinaria.Plugins;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AccesoVeterinaria.Operations
{
    public class veterinarioDAO
    {
        private readonly BdVeterinariaContext contexto; // Ahora es 'readonly' y se inyecta

        // Constructor para inyección de dependencias
        public veterinarioDAO(BdVeterinariaContext dbContext)
        {
            contexto = dbContext;
        }

        public async Task<Veterinario> login(string username, string password)
        {
            string passHash = HashUtil.ObtenerMD5(password);
            var veterinario = await contexto.Veterinarios
                .Where(a => a.Usuario == username && a.Contrasena == passHash)
                .FirstOrDefaultAsync();
            return veterinario;
        }

        public List<Veterinario> seleccionarTodos()
        {
            var veterinarios = contexto.Veterinarios.ToList();
            return veterinarios;
        }

        public Veterinario seleccionarVeterinario(int id)
        {
            var veterinario = contexto.Veterinarios.FirstOrDefault(v => v.IdVeterinario == id);
            return veterinario;
        }

        public async Task <bool> insertar(Veterinario veterinario)
        {
            bool existe = contexto.Veterinarios.Any(v => v.Usuario == veterinario.Usuario);

            if (existe)
            {
                return false;
            }
            veterinario.Contrasena = HashUtil.ObtenerMD5(veterinario.Contrasena);
            contexto.Veterinarios.Add(veterinario);
            contexto.SaveChanges();
            return true;
        }

        public async Task<bool> actulizarPass(string usuario, string newPass)
        {
            var vet = contexto.Veterinarios.FirstOrDefault(v => v.Usuario == usuario);
            if (vet == null)
            {
                return false;
            }
            vet.Contrasena = HashUtil.ObtenerMD5(newPass);
            contexto.SaveChanges();
            return true;
        }

        public async Task <bool> actualizar(int id, Veterinario veterinarioActualizado)
        {
            try
            {
                Console.WriteLine($"[veterinarioDAO] Intentando actualizar veterinario con ID: {id}");

                var veterinarioExistente = contexto.Veterinarios.FirstOrDefault(v => v.IdVeterinario == id);

                if (veterinarioExistente == null)
                {
                    Console.WriteLine($"[veterinarioDAO] Veterinario con ID {id} no encontrado para actualizar. Retornando false.");
                    return false; 
                }

                
                if (veterinarioExistente.Usuario != veterinarioActualizado.Usuario) 
                {
                    bool usuarioEnUso = contexto.Veterinarios.Any(v => v.Usuario == veterinarioActualizado.Usuario && v.IdVeterinario != id);
                    if (usuarioEnUso)
                    {
                        Console.WriteLine($"[veterinarioDAO] Error al actualizar: Nuevo usuario '{veterinarioActualizado.Usuario}' ya está en uso por otro veterinario.");
                        return false;
                    }
                }

                veterinarioExistente.Usuario = veterinarioActualizado.Usuario;
                veterinarioExistente.Nombre = veterinarioActualizado.Nombre;
                veterinarioExistente.Telefono = veterinarioActualizado.Telefono;
                veterinarioExistente.Correo = veterinarioActualizado.Correo;
                veterinarioExistente.Activo = veterinarioActualizado.Activo; 

               
                if (!string.IsNullOrEmpty(veterinarioActualizado.Contrasena))
                {
                    string nuevoHash = HashUtil.ObtenerMD5(veterinarioActualizado.Contrasena);
                    if (veterinarioExistente.Contrasena != nuevoHash) 
                    {
                        veterinarioExistente.Contrasena = nuevoHash;
                        Console.WriteLine($"[veterinarioDAO] Contraseña de veterinario {id} actualizada.");
                    }
                }


                
                contexto.SaveChanges();

                Console.WriteLine($"[veterinarioDAO] Veterinario con ID {id} actualizado exitosamente. Retornando true.");
                return true;
            }
            catch (Exception ex)
            {
   
                Console.WriteLine($"[veterinarioDAO] ERROR al actualizar veterinario con ID {id}: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"[veterinarioDAO] Inner Exception: {ex.InnerException.Message}");
                }
                return false;
            }
        }
        

        public async Task < bool> eliminar(int idVeterinario)
        {
            try
            {
                var veterinario = contexto.Veterinarios.FirstOrDefault(v => v.IdVeterinario == idVeterinario);

                if (veterinario == null)
                {
                    Console.WriteLine($"[veterinarioDAO] Veterinario con ID {idVeterinario} no encontrado.");
                    return false;
                }

         
                contexto.Consulta.RemoveRange(
                    contexto.Consulta.Where(c => c.IdVeterinario == idVeterinario));

                contexto.Veterinarios.Remove(veterinario);

                contexto.SaveChanges();

                Console.WriteLine($"[veterinarioDAO] Veterinario con ID {idVeterinario} y sus consultas asociadas eliminados exitosamente.");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[veterinarioDAO] ERROR al eliminar veterinario con ID {idVeterinario}: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"[veterinarioDAO] Inner Exception: {ex.InnerException.Message}");
                }
                return false;
            }
        }

        public List<VeterinarioMascota> seleccionarVeterinarioMascotaPorVeterinario(int idVeterinario)
        {
            var query = from c in contexto.Consulta
                        join v in contexto.Veterinarios on c.IdVeterinario equals v.IdVeterinario
                        join m in contexto.Mascota on c.IdMascota equals m.IdMascota
                        where v.IdVeterinario == idVeterinario
                        select new VeterinarioMascota
                        {
                            NombreVetirinario = v.Nombre,
                            NombreMascota = m.Nombre
                        };

            return query.ToList();
        }

        // Métodos Get para estadísticas
        public int GetDuenosRegistrados() => contexto.Dueños.Count();
        public int GetMascotasRegistradas() => contexto.Mascota.Count();
        public int GetVeterinariosActivos() => contexto.Veterinarios.Count(v => v.Activo == true);
        public int GetConsultasRealizadas() => contexto.Consulta.Count();
        public int GetVacunasAplicadas() => contexto.Vacunas.Count();
        public int GetEnfermedadesComunes() => contexto.Enfermedads.Count();

        public List<Statistic> GetChartStatistics()
        {
            var statistics = new List<Statistic>
            {
                new Statistic { Label = "Dueños Registrados", Value = GetDuenosRegistrados() },
                new Statistic { Label = "Mascotas Registradas", Value = GetMascotasRegistradas() },
                new Statistic { Label = "Veterinarios Activos", Value = GetVeterinariosActivos() },
                new Statistic { Label = "Consultas Realizadas", Value = GetConsultasRealizadas() },
                new Statistic { Label = "Vacunas Aplicadas", Value = GetVacunasAplicadas() },
                new Statistic { Label = "Enfermedades Comunes", Value = GetEnfermedadesComunes() }
            };
            return statistics;
        }
    }
}