﻿using AccesoVeterinaria.Context;
using AccesoVeterinaria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Operations
{
    public class ConsultumDAO
    {

        private readonly BdVeterinariaContext contexto; // Hazlo readonly y privado

        // Constructor para inyección de dependencia
        public ConsultumDAO(BdVeterinariaContext dbContext)
        {
            contexto = dbContext;
        }


        // *** NUEVO MÉTODO PARA FILTRAR POR NOMBRE DE VETERINARIO ***
        public List<ConsultaMV> seleccionarConsultasPorNombreVeterinario(string nombreVeterinario)
        {
            if (string.IsNullOrEmpty(nombreVeterinario))
            {
                return new List<ConsultaMV>();
            }

            // Convertir el nombre de búsqueda a minúsculas para una comparación sin distinción de mayúsculas/minúsculas
            string nombreBusquedaLower = nombreVeterinario.ToLower();

            var query = from d in contexto.Consulta
                        join m in contexto.Mascota on d.IdMascota equals m.IdMascota
                        join n in contexto.Veterinarios on d.IdVeterinario equals n.IdVeterinario
                        // Aquí el cambio: usar Contains() y ToLower()
                        where n.Nombre.ToLower().Contains(nombreBusquedaLower)
                        select new ConsultaMV
                        {
                            detalleConsulta = d.Motivo,
                            nombreMascota = m.Nombre,
                            nombreVeterinario = n.Nombre
                        };
            return query.ToList();
        }
        public List<Consultum> SeleccionarConsultas()
        {
            var consultas = contexto.Consulta.ToList<Consultum>();
            return consultas;
        }

        public Consultum seleccionarConsulta(int id)
        {
            var consulta = contexto.Consulta.Where(a => a.IdConsultas == id).FirstOrDefault();
            return consulta;
        }

        public bool insertarConsulta(DateOnly? fechaConsulta, String motivo, String tratamiento, String observaciones, int idMascota, int idVeterinario)
        {
            try
            {
                Consultum consulta = new Consultum();
                consulta.FechaConsulta = fechaConsulta;
                consulta.Motivo = motivo;
                consulta.Tratamiento = tratamiento;
                consulta.Observaciones = observaciones;
                consulta.IdMascota = idMascota;
                consulta.IdVeterinario = idVeterinario;

                contexto.Consulta.Add(consulta);
                contexto.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                // Aquí podrías loguear el error si es necesario
                return false;
            }
        }

        public bool actualizarConsulta(int idConsultas, DateOnly? fechaConsulta, String motivo, String tratamiento, String observaciones, int idMascota, int idVeterinario)
        {
            try
            {
                var consulta = contexto.Consulta.Where(d => d.IdConsultas == idConsultas).FirstOrDefault(); // Ubica la consulta por el ID

                if (consulta == null)
                {
                    return false;
                }

                consulta.FechaConsulta = fechaConsulta;
                consulta.Motivo = motivo;
                consulta.Tratamiento = tratamiento;
                consulta.Observaciones = observaciones;
                consulta.IdMascota = idMascota;
                consulta.IdVeterinario = idVeterinario;

                contexto.SaveChanges(); // Guardar los cambios en la base de datos
                return true;
            }
            catch (Exception ex)
            {
                // Puedes loguear el error si es necesario
                return false;
            }
        }

        public bool eliminarConsulta(int idConsultas)
        {
            try
            {
                Console.WriteLine($"[ConsultumDAO] Intentando eliminar consulta con ID: {idConsultas}");
                var consulta = contexto.Consulta.Where(d => d.IdConsultas == idConsultas).FirstOrDefault();

                if (consulta == null)
                {
                    Console.WriteLine($"[ConsultumDAO] Consulta con ID {idConsultas} no encontrada.");
                    return false;
                }
                else
                {
                    contexto.Consulta.Remove(consulta);
                    contexto.SaveChanges();
                    Console.WriteLine($"[ConsultumDAO] Consulta con ID {idConsultas} eliminada exitosamente.");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ConsultumDAO] ERROR al eliminar consulta con ID {idConsultas}: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"[ConsultumDAO] Inner Exception: {ex.InnerException.Message}");
                }
                return false;
            }
        }

        // ***** NUEVO MÉTODO: Obtener consultas por ID de Veterinario *****
        public List<AccesoVeterinaria.Models.Consultum> ObtenerConsultasPorVeterinario(int idVeterinario) // Asumo que Consultum tiene IdVeterinario
        {
            // Filtra las consultas por el IdVeterinario asociado
            return contexto.Consulta.Where(c => c.IdVeterinario == idVeterinario).ToList();
        }



        public List<ConsultaVeterinario> seleccionarConsultaVeterinario(String veterinario)
        {
            var query = from c in contexto.Consulta
                        join v in contexto.Veterinarios on c.IdVeterinario equals v.IdVeterinario
                        join m in contexto.Mascota on c.IdMascota equals m.IdMascota
                        join hm in contexto.HistorialMedicos on m.IdMascota equals hm.IdMascota
                        join e in contexto.Enfermedads on hm.IdEnfermedad equals e.IdEnfermedad
                        where v.Nombre == veterinario
                        select new ConsultaVeterinario
                        {
                            Id = c.IdConsultas,
                            FechaConsulta = c.FechaConsulta,
                            Motivo = c.Motivo,
                            NombreMascota = m.Nombre,
                            Enfermedad = e.Nombre,
                            Tratamiento = c.Tratamiento,
                            Observaciones = c.Observaciones
                        };

            return query
                .OrderBy(c => c.Id)  // 🔽 Ordena por ID de consulta
                .ToList();

        }

    }
}
