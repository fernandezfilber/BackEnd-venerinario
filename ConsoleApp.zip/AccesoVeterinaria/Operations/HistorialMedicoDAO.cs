﻿using AccesoVeterinaria.Context;
using AccesoVeterinaria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Operations
{

    public class HistorialMedicoDAO
    {
        BdVeterinariaContext contexto = new BdVeterinariaContext();

        // Seleccionar historial médico por IdMascota
        public List<HistorialMedico> seleccionarHistorialPorMascota(int idMascota)
        {
            return contexto.HistorialMedicos
                .Where(h => h.IdMascota == idMascota)
                .ToList();
        }

        // Actualizar historial médico
        public bool actualizarHistorial(HistorialMedico historialActualizado)
        {
            try
            {
                var historialExistente = contexto.HistorialMedicos
                    .FirstOrDefault(h => h.IdHistorialMedico == historialActualizado.IdHistorialMedico);

                if (historialExistente != null)
                {
                    // Actualiza los campos necesarios (solo IdEnfermedad y IdMascota en este caso)
                    historialExistente.IdEnfermedad = historialActualizado.IdEnfermedad;
                    historialExistente.IdMascota = historialActualizado.IdMascota;

                    contexto.SaveChanges();
                    return true;
                }
                else
                {
                    // No se encontró el historial con ese ID
                    return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al actualizar historial médico: " + ex.Message);
                return false;
            }
        }


        // Agregar historial médico
        public bool agregarHistorial(HistorialMedico historial)
        {
            try
            {
                contexto.HistorialMedicos.Add(historial);
                contexto.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al agregar historial médico: " + ex.Message);
                return false;
            }
        }

        // Eliminar historial médico por ID
        public bool eliminarHistorial(int id)
        {
            try
            {
                var historial = contexto.HistorialMedicos
                    .FirstOrDefault(h => h.IdHistorialMedico == id);

                if (historial != null)
                {
                    contexto.HistorialMedicos.Remove(historial);
                    contexto.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al eliminar historial médico: " + ex.Message);
                return false;
            }
        }
    }
}

