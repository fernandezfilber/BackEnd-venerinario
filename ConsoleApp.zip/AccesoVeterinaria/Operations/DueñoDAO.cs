﻿using AccesoVeterinaria.Context;
using AccesoVeterinaria.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Operations
{
    public class DueñoDAO
    {
        private readonly BdVeterinariaContext contexto;

        // 🔧 Constructor que recibe el contexto desde la inyección de dependencias
        public DueñoDAO(BdVeterinariaContext contexto)
        {
            this.contexto = contexto;
        }

        public List<Dueño> seleccionarTodos()
        {
            return contexto.Dueños.ToList();
        }

        public Dueño seleccionarDueños(int id)
        {
            return contexto.Dueños.FirstOrDefault(a => a.IdDueño == id);
        }

        public async Task<bool> insertar(Dueño dueño)
        {
            bool existe = contexto.Dueños.Any(d => d.Correo == dueño.Correo);

            if (existe)
            {
                return false;
            }

            contexto.Dueños.Add(dueño);
            await contexto.SaveChangesAsync();
            return true;
        }

        public async Task<bool> Actualizar(int id, Dueño duenoActualizado)
        {
            try
            {
                Console.WriteLine($"[duenoDAO] Intentando actualizar dueño con ID: {id}");

                var duenoExistente = contexto.Dueños.FirstOrDefault(d => d.IdDueño == id);

                if (duenoExistente == null)
                {
                    Console.WriteLine($"[duenoDAO] Dueño con ID {id} no encontrado para actualizar.");
                    return false;
                }

                duenoExistente.Nombre = duenoActualizado.Nombre;
                duenoExistente.Telefono = duenoActualizado.Telefono;
                duenoExistente.Direccion = duenoActualizado.Direccion;
                duenoExistente.Correo = duenoActualizado.Correo;

                await contexto.SaveChangesAsync();

                Console.WriteLine($"[duenoDAO] Dueño con ID {id} actualizado exitosamente.");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[duenoDAO] ERROR al actualizar dueño: {ex.Message}");
                if (ex.InnerException != null)
                    Console.WriteLine($"[duenoDAO] Inner Exception: {ex.InnerException.Message}");
                return false;
            }
        }

        public DueñoMascota seleccionarDueñoPorNombreMascota(string nombreMascota)
        {
            var query = from d in contexto.Dueños
                        join m in contexto.Mascota on d.IdDueño equals m.IdDueño
                        where m.Nombre == nombreMascota
                        select new DueñoMascota
                        {
                            NombreDueño = d.Nombre,
                            NombreMascota = m.Nombre
                        };

            return query.FirstOrDefault();
        }

        public async Task<bool> eliminar(int idDueno)
        {
            try
            {
                var dueño = contexto.Dueños
                                    .Include(d => d.Mascota)
                                    .FirstOrDefault(d => d.IdDueño == idDueno);

                if (dueño == null)
                {
                    Console.WriteLine($"[DueñoDAO] Dueño con ID {idDueno} no encontrado.");
                    return false;
                }

                foreach (var mascota in dueño.Mascota)
                {
                    contexto.Vacunas.RemoveRange(
                        contexto.Vacunas.Where(v => v.IdMascota == mascota.IdMascota));

                    contexto.Consulta.RemoveRange(
                        contexto.Consulta.Where(c => c.IdMascota == mascota.IdMascota));

                    contexto.HistorialMedicos.RemoveRange(
                        contexto.HistorialMedicos.Where(h => h.IdMascota == mascota.IdMascota));
                }

                contexto.Mascota.RemoveRange(dueño.Mascota);
                contexto.Dueños.Remove(dueño);

                await contexto.SaveChangesAsync();

                Console.WriteLine($"[DueñoDAO] Dueño con ID {idDueno} y sus datos relacionados eliminados exitosamente.");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DueñoDAO] ERROR al eliminar dueño con ID {idDueno}: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"[DueñoDAO] Inner Exception: {ex.InnerException.Message}");
                }
                return false;
            }
        }
    }
}
