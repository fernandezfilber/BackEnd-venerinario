﻿using AccesoVeterinaria.Context;
using AccesoVeterinaria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Operations
{
    public class EnfermedadDAO
    {
        BdVeterinariaContext contexto = new BdVeterinariaContext();

        // Obtener todas las enfermedades
        public List<Enfermedad> seleccionarTodas()
        {
            return contexto.Enfermedads.ToList();
        }

        // Obtener una enfermedad por ID
        public Enfermedad seleccionarPorId(int id)
        {
            return contexto.Enfermedads.FirstOrDefault(e => e.IdEnfermedad == id);
        }

        // Agregar nueva enfermedad
        public bool agregar(Enfermedad enfermedad)
        {
            try
            {
                contexto.Enfermedads.Add(enfermedad);
                contexto.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al agregar enfermedad: " + ex.Message);
                return false;
            }
        }

        // Actualizar enfermedad existente
        public bool actualizar(Enfermedad enfermedadActualizada)
        {
            try
            {
                var enfermedadExistente = contexto.Enfermedads
                    .FirstOrDefault(e => e.IdEnfermedad == enfermedadActualizada.IdEnfermedad);

                if (enfermedadExistente != null)
                {
                    enfermedadExistente.Nombre = enfermedadActualizada.Nombre;
                    enfermedadExistente.Descripcion = enfermedadActualizada.Descripcion;

                    contexto.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al actualizar enfermedad: " + ex.Message);
                return false;
            }
        }

        // Eliminar enfermedad por ID
        public bool eliminar(int id)
        {
            try
            {
                var enfermedad = contexto.Enfermedads
                    .FirstOrDefault(e => e.IdEnfermedad == id);

                if (enfermedad != null)
                {
                    contexto.Enfermedads.Remove(enfermedad);
                    contexto.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al eliminar enfermedad: " + ex.Message);
                return false;
            }
        }
    }

}
