﻿using AccesoVeterinaria.Context;
using AccesoVeterinaria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Operations
{
    public class VacunaDAO
    {
        public BdVeterinariaContext contexto = new BdVeterinariaContext();
        public List<Vacuna> seleccionarTodas()
        {
            var vacunas = contexto.Vacunas.ToList<Vacuna>();
            return vacunas;
        }

        public Vacuna seleccionarVacuna(int id)
        {
            var vacuna = contexto.Vacunas.Where(a => a.IdVacunas == id).FirstOrDefault();
            return vacuna;
        }

        public Vacuna seleccionarVacunaPorNombreYIdMascota(string nombreVacuna, int idMascota)
        {
            var vacuna = contexto.Vacunas
                         .Where(v => v.NombreVacuna.Equals(nombreVacuna) && v.IdMascota == idMascota)
                         .FirstOrDefault();
            return vacuna;
        }



        public bool insertar(string nombreVacuna, DateOnly? fechaAplicacion, string proximaDosis, int? idMascota)
        {
            try
            {
                Vacuna vacuna = new Vacuna();
                vacuna.NombreVacuna = nombreVacuna;
                if (fechaAplicacion.HasValue)
                    vacuna.FechaAplicacion = fechaAplicacion.Value;

                vacuna.ProximaDosis = proximaDosis;
                vacuna.IdMascota = idMascota;

                contexto.Vacunas.Add(vacuna);
                contexto.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool actualizar(int id, string nombreVacuna, DateOnly? fechaAplicacion, string proximaDosis, int? idMascota)
        {
            try
            {
                var vacuna = seleccionarVacuna(id); // Este método debe buscar la vacuna por su ID

                if (vacuna == null)
                {
                    return false;
                }
                else
                {
                    vacuna.NombreVacuna = nombreVacuna;
                    if (fechaAplicacion.HasValue)
                        vacuna.FechaAplicacion = fechaAplicacion.Value;

                    vacuna.ProximaDosis = proximaDosis;
                    vacuna.IdMascota = idMascota;

                    contexto.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool eliminar(int id)
        {
            try
            {
                var vacuna = seleccionarVacuna(id); // Método que busca la vacuna por ID

                if (vacuna == null)
                {
                    return false;
                }
                else
                {
                    contexto.Vacunas.Remove(vacuna);
                    contexto.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public List<VacunaMascota> seleccionarVacunaMascota()
        {
            var query = from v in contexto.Vacunas
                        join m in contexto.Mascota on v.IdMascota equals m.IdMascota
                        select new VacunaMascota
                        {
                            NombreVacuna = v.NombreVacuna,
                            NombreMascota = m.Nombre
                        };

            return query.ToList();
        }

        public List<VacunaVeterinario> SeleccionarVacunasPorVeterinario(int idVeterinario)
        {
            var query = from v in contexto.Vacunas
                        join m in contexto.Mascota on v.IdMascota equals m.IdMascota
                        join c in contexto.Consulta on m.IdMascota equals c.IdMascota
                        where c.IdVeterinario == idVeterinario
                        select new VacunaVeterinario
                        {
                            IdVacuna = v.IdVacunas,
                            NombreVacuna = v.NombreVacuna,
                            FechaAplicacion = v.FechaAplicacion,
                            ProximaDosis = v.ProximaDosis,
                            NombreMascota = m.Nombre,
                            Especie = m.Especie,
                            Raza = m.Raza,
                            Edad = m.Edad,
                        };

            return query.ToList();
        }


        public bool insertarYAsignarVacuna(string nombreVacuna, DateTime fechaAplicacion, string proximaDosis, int idMascota)
        {
            try
            {
                // Verificamos si ya existe una vacuna igual para esta mascota en la misma fecha (opcional)
                var existeVacuna = contexto.Vacunas
                   .FirstOrDefault(v =>
                        v.NombreVacuna == nombreVacuna &&
                        v.IdMascota == idMascota &&
                        v.FechaAplicacion != null && v.FechaAplicacion == DateOnly.FromDateTime(fechaAplicacion));





                if (existeVacuna == null)
                {
                    // Crear e insertar la nueva vacuna
                    Vacuna nuevaVacuna = new Vacuna();
                    nuevaVacuna.NombreVacuna = nombreVacuna;
                    nuevaVacuna.FechaAplicacion = DateOnly.FromDateTime(fechaAplicacion);
                    nuevaVacuna.ProximaDosis = proximaDosis;
                    nuevaVacuna.IdMascota = idMascota;

                    contexto.Vacunas.Add(nuevaVacuna);
                    contexto.SaveChanges();
                }
                else
                {
                    // Ya existe la vacuna aplicada a esta mascota en esa fecha, podrías decidir no hacer nada o actualizar info
                    // Aquí podrías agregar lógica si quieres actualizar la vacuna existente
                }
                return true;
            }
            catch (Exception ex)
            {
                // Puedes loguear el error si quieres para depurar
                return false;
            }
        }


        public bool EliminarVacuna(int id)
        {
            try
            {
                var vacuna = contexto.Vacunas.FirstOrDefault(v => v.IdVacunas == id);

                if (vacuna != null)
                {
                    contexto.Vacunas.Remove(vacuna);
                    contexto.SaveChanges();
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }






    }
}

