﻿using AccesoVeterinaria.Context;
using AccesoVeterinaria.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoVeterinaria.Operations
{
    public class MascotaDAO
    {
        public BdVeterinariaContext contexto = new BdVeterinariaContext();

        // 1. Seleccionar todas las mascotas
        public List<Mascotum> SeleccionarTodas()
        {
            using (var context = new BdVeterinariaContext())
            {
                return context.Mascota
                    .Include(m => m.IdDueñoNavigation) // Esto une la tabla dueño
                    .ToList();
            }
        }

        // 2. Seleccionar mascota por ID
        public Mascotum SeleccionarPorId(int id)
        {
            return contexto.Mascota.FirstOrDefault(m => m.IdMascota == id);
        }

        // 3. Seleccionar mascotas por dueño
        public List<Mascotum> SeleccionarPorDueño(int idDueño)
        {
            return contexto.Mascota.Where(m => m.IdDueño == idDueño).ToList();
        }

        // 4. Insertar nueva mascota
        // En MascotumDAO.cs
        public bool Insertar(string nombre, string especie, string raza, int? edad, string sexo, int? idDueño, out string mensajeError)
        {
            mensajeError = "";

            try
            {
                Mascotum mascota = new Mascotum
                {
                    Nombre = nombre,
                    Especie = especie,
                    Raza = raza,
                    Edad = edad,
                    Sexo = sexo,
                    IdDueño = idDueño
                };

                contexto.Mascota.Add(mascota);
                contexto.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                mensajeError = "Error al insertar Mascota: " + ex.Message;

#if DEBUG
                throw; // 🔥 Esto solo relanza la excepción si estás en modo Debug
#endif

                return false; // En producción, devuelve false y guarda el mensaje
            }
        }



        // 5. Actualizar mascota
        public bool Actualizar(int idMascota, string nombre, string especie, string raza, int? edad, string sexo, int? idDueño)
        {

            try
            {
                var mascota = SeleccionarPorId(idMascota);
                if (mascota == null) return false;

                mascota.Nombre = nombre;
                mascota.Especie = especie;
                mascota.Raza = raza;
                mascota.Edad = edad;
                mascota.Sexo = sexo;
                mascota.IdDueño = idDueño;

                contexto.SaveChanges();
                return true;
            }
            catch(Exception ex) 
            {
                throw;
                return false;
            }
        }

        // 6. Eliminar mascota (y relaciones si aplica)
        public bool Eliminar(int idMascota)
        {
            try
            {
                var mascota = SeleccionarPorId(idMascota);
                if (mascota == null) return false;

                // Eliminar primero historial, vacunas, consultas si aplica
                contexto.HistorialMedicos.RemoveRange(
                    contexto.HistorialMedicos.Where(h => h.IdMascota == idMascota));

                contexto.Vacunas.RemoveRange(
                    contexto.Vacunas.Where(v => v.IdMascota == idMascota));

                contexto.Consulta.RemoveRange(
                    contexto.Consulta.Where(c => c.IdMascota == idMascota));

                contexto.Mascota.Remove(mascota);
                contexto.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        // 7. Obtener mascotas con sus vacunas
        public List<MascotaVacuna> ObtenerMascotasConVacunas()
        {
            var query = from m in contexto.Mascota
                        join v in contexto.Vacunas on m.IdMascota equals v.IdMascota
                        select new MascotaVacuna
                        {
                            NombreMascota = m.Nombre,
                            Especie = m.Especie,
                            NombreVacuna = v.NombreVacuna,
                            FechaAplicacion = v.FechaAplicacion,
                            ProximaDosis = v.ProximaDosis,
                        };
            return query.ToList();
        }
    }

}
