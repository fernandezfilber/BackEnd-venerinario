﻿// See https://aka.ms/new-console-template for more information

using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;



DueñoDAO opDueño = new DueñoDAO();

// Insertar un nuevo dueño
//opDueño.insertar("Carlos Pérez", "987654321", "Av. Siempre Viva 123", "carlos.perez@email.com");
//opDueño.insertar("Laura Ramírez", "912345678", "Jr. Las Flores 456", "laura.ramirez@email.com");

// Actualizar un dueño existente
//opDueño.actualizar(2, "Laura Ramírez", "987654321", "Calle Falsa 456", "laura.r@email.com");

// Eliminar un dueño
//opDueño.eliminar(3);

// Seleccionar todos los dueños
var dueños = opDueño.seleccionarTodos();
foreach (var dueño in dueños)
{
    Console.WriteLine(dueño.Nombre);
}

Console.WriteLine("*************************");

// Seleccionar un dueño por ID
var dueñoSeleccionado = opDueño.seleccionarDueños(2);

if (dueñoSeleccionado != null)
{
    Console.WriteLine("El dueño con el ID = 2 es: " + dueñoSeleccionado.Nombre);
}
else
{
    Console.WriteLine("No existe");
}

Console.WriteLine("##################################################");

// Mostrar relación entre dueño y mascota
//var dueñoMascota = opDueño.seleccionarDueñoMascota();



Console.WriteLine("------------------------------------------");

Console.WriteLine("Grupo 2: \n ---> Flores Quiroz \n ---> Fernandez Bendezú \n ---> Purizaca Huamaní \n--->Uipan Colan \n--->Chavez Peña");


