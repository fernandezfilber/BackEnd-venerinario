﻿using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Web_Api.Controllers
{
    [Route("api/")]
    [ApiController]
   
    public class MascotaController : ControllerBase
    {
        private MascotaDAO mascotaDAO = new MascotaDAO();

        [HttpGet("Mascotas")]
        public List<Mascotum> seleccionarTodas()
        {
            return mascotaDAO.SeleccionarTodas();
        }

        [HttpGet("Mascota")]
        public Mascotum seleccionarPorId(int id)
        {
            return mascotaDAO.SeleccionarPorId(id);
        }

        [HttpGet("MascotasPorDueno")]
        public List<Mascotum> seleccionarPorDueno(int idDueno)
        {
            return mascotaDAO.SeleccionarPorDueño(idDueno);
        }

        [HttpPost("InsertarMascota")]
        public IActionResult Insertar([FromBody] Mascotum mascota)
        {
            string mensajeError = string.Empty;

            bool resultado = mascotaDAO.Insertar(
                mascota.Nombre,
                mascota.Especie,
                mascota.Raza,
                mascota.Edad,
                mascota.Sexo,
                mascota.IdDueño,
                out mensajeError
            );

            if (resultado)
            {
                return Ok(new { exito = true, mensaje = "Mascota registrada con éxito." });
            }
            else
            {
                return BadRequest(new { exito = false, mensaje = mensajeError ?? "No se pudo registrar la mascota. Verifique los datos." });
            }
        }

        [HttpPut("Mascota")]
        public IActionResult Actualizar(int id, [FromBody] Mascotum mascota)
        {
            bool resultado = mascotaDAO.Actualizar(
                id,
                mascota.Nombre,
                mascota.Especie,
                mascota.Raza,
                mascota.Edad,
                mascota.Sexo,
                mascota.IdDueño
            );

            if (resultado)
            {
                return Ok(new { mensaje = "Mascota actualizada correctamente" });
            }
            else
            {
                return BadRequest(new { error = "No se pudo actualizar la mascota" });
            }
        }

        [HttpDelete("Mascota")]
        public bool eliminarMascota(int idMascota)
        {
            return mascotaDAO.Eliminar(idMascota);
        }

        [HttpGet("MascotaVacunas")]
        public IActionResult ObtenerMascotasConVacunas()
        {
            try
            {
                var mascotasConVacunas = mascotaDAO.ObtenerMascotasConVacunas();
                return Ok(mascotasConVacunas);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Error interno al obtener las mascotas con vacunas" });
            }
        }
    }
}
