﻿using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web_Api.DTOs;
using Web_Api.Services;

namespace Web_Api.Controllers
{
    [Route("api")]
    [ApiController]
    [Authorize(Roles = "Admin,Veterinario, Operador")] 
    public class VeterinarioController : ControllerBase
    {
        private readonly VeterinarioServices _services;
        private readonly veterinarioDAO veterianriodao;

        public VeterinarioController(VeterinarioServices services, veterinarioDAO veterinarioDAO)
        {
            _services = services ?? throw new ArgumentNullException(nameof(services));
            veterianriodao = veterinarioDAO ?? throw new ArgumentNullException(nameof(veterinarioDAO));
        }

        [AllowAnonymous] 
        [HttpPost("autenticacion")]
        public async Task<IActionResult> login([FromBody] LoginDTO loginDTO)
        {
            var vet = await _services.login(loginDTO);

            if (vet != null)
            {
                return Ok(new
                {
                    exito = true,
                    mensaje = "Credenciales correctas",
                    token = vet.Token,
                    usuario = new
                    {
                        usuario = vet.Usuario.Usuario,
                        nombre = vet.Usuario.Nombre,
                        rol = vet.Usuario.Rol.ToString() 
                    }
                });
            }
            else
            {
                return Unauthorized(new { exito = false, mensaje = "Credenciales incorrectas" });
            }
        }


        [HttpPost("RegistroVeterinario")]
        public async Task<IActionResult> insertarVeterinario([FromBody] VeterinarioDTO veterinario)
        {
            if (veterinario == null || string.IsNullOrWhiteSpace(veterinario.Usuario) || string.IsNullOrWhiteSpace(veterinario.Contrasena))
                return BadRequest(new { mensaje = " datos Imcompletos " });

            bool insertar = await _services.insertarVet(veterinario);

            if (insertar)
            {
                return Ok(new { exito = true, mensaje = "Veterinario registrado" });
            }
            else
            {
                return BadRequest(new { exito = false, mensaje = "Error al registrar el veterinario" });
            }
        }

        [HttpPatch("ActualizarPass")]
        public async Task<IActionResult> actualizarPass([FromBody] ActualizarPassDTO actualizarPassDTO)
        {
            if (actualizarPassDTO == null || string.IsNullOrWhiteSpace(actualizarPassDTO.pass) ||
                string.IsNullOrWhiteSpace(actualizarPassDTO.newpass))
                return BadRequest(new { mensaje = "Usuario, contraseña actual y nueva contraseña son necesarios" });

            bool actualizar = await _services.actualizarPass(actualizarPassDTO);

            if (!actualizar)
                return BadRequest(new { exito = false, mensaje = "Error al actualizar contraseña" });

            return Ok(new { exito = true, mensaje = "Contraseña actualizada" });
        }

        [HttpGet("Lista")]
        [Authorize(Roles = "Admin,Veterinario,Operador")]
        public ActionResult<List<ListaVetDTO>> GetTodosLosVeterinarios()
        {
            List<ListaVetDTO> veterinarios = _services.ObtenerTodosLosVeterinarios();
            return Ok(veterinarios);
        }

        [HttpGet("Veterinario")]
        public IActionResult seleccionarVeterinario(int id)
        {
            var veterinario = veterianriodao.seleccionarVeterinario(id);

            if (veterinario != null)
                return Ok(veterinario);
            else
                return NotFound(new { mensaje = "No se encontró un veterinario con ese ID." });
        }

        [HttpPut("Veterinario/Actualizar")]

        public async Task<IActionResult> ActualizarVeterinario(int id, [FromBody] VeterinarioDTO veterinarioDTO)
        {
            if (veterinarioDTO == null)
                return BadRequest(new { mensaje = "Datos inválidos." });

            bool actualizado = await _services.ActualizarVeterinario(id, veterinarioDTO);

            if (actualizado)
                return Ok(new { mensaje = "Veterinario actualizado correctamente." });
            else
                return NotFound(new { mensaje = "No se pudo actualizar el veterinario. Verifique los datos." });
        }

        [HttpDelete("Veterinario")]
        public async Task<bool> EliminarVeterinario(int id)
        {
            return await veterianriodao.eliminar(id);
        }

        [HttpGet("DuenosRegistrados")]
        public IActionResult GetDuenosRegistrados()
        {
            int count = _services.GetDuenosRegistrados();
            return Ok(new { cantidad = count });
        }

        [HttpGet("MascotasRegistradas")]
        public IActionResult GetMascotasRegistradas()
        {
            int count = _services.GetMascotasRegistradas();
            return Ok(new { cantidad = count });
        }

        [HttpGet("VeterinariosActivos")]
        public IActionResult GetVeterinariosActivos()
        {
            int count = _services.GetVeterinariosActivos();
            return Ok(new { cantidad = count });
        }

        [HttpGet("ConsultasRealizadas")]
        public IActionResult GetConsultasRealizadas()
        {
            int count = _services.GetConsultasRealizadas();
            return Ok(new { cantidad = count });
        }

        [HttpGet("VacunasAplicadas")]
        public IActionResult GetVacunasAplicadas()
        {
            int count = _services.GetVacunasAplicadas();
            return Ok(new { cantidad = count });
        }

        [HttpGet("EnfermedadesComunes")]
        public IActionResult GetEnfermedadesComunes()
        {
            int count = _services.GetEnfermedadesComunes();
            return Ok(new { cantidad = count });
        }

        [HttpGet("estadisticas")]
        public IActionResult GetChartStatistics()
        {
            try
            {
                var statistics = _services.GetChartStatistics();
                if (statistics == null || !statistics.Any())
                    return NotFound(new { mensaje = "No se encontraron estadísticas." });

                return Ok(statistics);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching chart statistics: {ex.Message}");
                return StatusCode(500, new { mensaje = "Error interno al obtener las estadísticas." });
            }
        }
    }
}

