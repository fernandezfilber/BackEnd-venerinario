﻿using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Web_Api.Controllers
{
    [Route("api")]
    [ApiController]
    public class VacunaController : ControllerBase
    {
        private VacunaDAO vacunadao = new VacunaDAO();

        [HttpGet("VacunasVeterinario")]
        public List<VacunaVeterinario> seleccionarVacunasPorVeterinario(int idVeterinario)
        {
            return vacunadao.SeleccionarVacunasPorVeterinario(idVeterinario);
        }

        [HttpGet("Vacuna*")]
        public Vacuna seleccionarVacuna(int id)
        {
            return vacunadao.seleccionarVacuna(id);
        }

        [HttpPut("Vacuna*")]
        public bool actualizarVacuna([FromBody] Vacuna vacuna)
        {
            return vacunadao.actualizar(
                vacuna.IdVacunas,
                vacuna.NombreVacuna,
                vacuna.FechaAplicacion,
                vacuna.ProximaDosis,
                vacuna.IdMascota
            );
        }

        [HttpPost("Vacuna")]
        public bool insertarYAsignarVacuna([FromBody] Vacuna vacuna, int idMascota)
        {
            return vacunadao.insertarYAsignarVacuna(
                vacuna.NombreVacuna,
                vacuna.FechaAplicacion != null ? vacuna.FechaAplicacion.ToDateTime(TimeOnly.MinValue) : DateTime.Now,
                vacuna.ProximaDosis,
                idMascota
            );
        }

        [HttpDelete("Vacuna")]
        public bool eliminarVacuna(int id)
        {
            return vacunadao.EliminarVacuna(id);
        }

    }
}
