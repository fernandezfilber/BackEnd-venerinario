﻿using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace Web_Api.Controllers
{
    [Route("api/")]
    [ApiController]
    public class ConsultaController : ControllerBase
    {
        private readonly ConsultumDAO consultumDAO;
        private readonly HistorialMedicoDAO historialMedicoDAO;
        private readonly MascotaDAO mascotaDAO;
        private readonly EnfermedadDAO enfermedadDAO;

        public ConsultaController(
            ConsultumDAO consultumDAO,
            HistorialMedicoDAO historialMedicoDAO,
            MascotaDAO mascotaDAO,
            EnfermedadDAO enfermedadDAO)
        {
            this.consultumDAO = consultumDAO;
            this.historialMedicoDAO = historialMedicoDAO;
            this.mascotaDAO = mascotaDAO;
            this.enfermedadDAO = enfermedadDAO;
        }

        [HttpGet("ConsultasVeterinario")]
        [Authorize(Roles = "Admin,Veterinario,Operador")]
        public List<ConsultaVeterinario> seleccionarConsultasVeterinario(string nombreVeterinario)
        {
            return consultumDAO.seleccionarConsultaVeterinario(nombreVeterinario);
        }

        [HttpGet("ConsultasMascotaVeterinario")]
        [Authorize(Roles = "Admin,Veterinario,Operador")]
        public List<ConsultaMV> GetConsultasPorVeterinario([FromQuery] string nombreVeterinario)
        {
            if (string.IsNullOrEmpty(nombreVeterinario))
            {
                return new List<ConsultaMV>();
            }

            return consultumDAO.seleccionarConsultasPorNombreVeterinario(nombreVeterinario);
        }

        [HttpGet("Consulta")]
        [Authorize(Roles = "Admin,Veterinario,Operador")]
        public Consultum seleccionarConsulta(int id)
        {
            return consultumDAO.seleccionarConsulta(id);
        }

        [HttpPut("Consulta")]
        [Authorize(Roles = "Admin,Veterinario,Operador")]
        public IActionResult actualizarConsulta([FromBody] Consultum consultum)
        {
            bool estado = consultumDAO.actualizarConsulta(consultum.IdConsultas, consultum.FechaConsulta, consultum.Motivo, consultum.Tratamiento, consultum.Observaciones, consultum.IdMascota, consultum.IdVeterinario);

            if (estado)
            {
                return Ok(new { exito = true, mensaje = "Consulta actualizada correctamente", });
            }
            else
            {
                return BadRequest(new { exito = false, mensaje = "Error al actualizar la consulta" });
            }
        }

        [HttpPost("Consulta")]
        [Authorize(Roles = "Admin,Veterinario,Operador")]
        public IActionResult insertarConsulta([FromBody] Consultum consultum)
        {
            bool estado = consultumDAO.insertarConsulta(consultum.FechaConsulta, consultum.Motivo, consultum.Tratamiento, consultum.Observaciones, consultum.IdMascota, consultum.IdVeterinario);

            if (estado)
            {
                return Ok(new { exito = true, mensaje = "Consulta registrado correctamente", }); //cuando le ponemos al costado de "Profesor registrado correctamente"  usuario = profesorRegistro.Usuario. Le ponemos el nombre del usuario registrado
            }
            else
            {
                return BadRequest(new { exito = false, mensaje = "Error al registrar la consulta" });
            }
        }

        [HttpDelete("Consulta")]
        [Authorize(Roles = "Admin,Veterinario,Operador")]
        public IActionResult eliminarConsulta(int idConsulta)
        {
            bool estado = consultumDAO.eliminarConsulta(idConsulta);

            if (estado)
            {
                return Ok(new { exito = true, mensaje = "Consulta eliminada correctamente", }); //cuando le ponemos al costado de "Profesor registrado correctamente"  usuario = profesorRegistro.Usuario. Le ponemos el nombre del usuario registrado
            }
            else
            {
                return BadRequest(new { exito = false, mensaje = "Error al elminiar la consulta" });
            }
        }

        // Obtener historial médico por ID de mascota
        [HttpGet("HistorialMedicoPorMascota")]
        public IActionResult ObtenerHistorialPorMascota(int idMascota)
        {
            var historial = historialMedicoDAO.seleccionarHistorialPorMascota(idMascota);
            if (historial == null || !historial.Any())
            {
                return NotFound(new { mensaje = "No se encontró historial médico para esta mascota." });
            }

            var historialesConNombres = historial.Select(h =>
            {
                var mascota = mascotaDAO.SeleccionarPorId(h.IdMascota ?? 0);
                var enfermedad = enfermedadDAO.seleccionarPorId(h.IdEnfermedad ?? 0);

                return new
                {
                    h.IdHistorialMedico,
                    NombreMascota = mascota?.Nombre ?? "Desconocida",
                    NombreEnfermedad = enfermedad?.Nombre ?? "Desconocida"
                };
            }).ToList();

            return Ok(historialesConNombres);
        }
    }
}
