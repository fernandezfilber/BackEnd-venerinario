﻿using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Web_Api.Controllers
{
    [Route("api")]
    [ApiController]
    public class HistorialMedicoController : ControllerBase
    {
        private HistorialMedicoDAO historialDao = new HistorialMedicoDAO();

        // Obtener el historial médico por idMascota
        [HttpGet("HistorialMedico")]
        public List<HistorialMedico> seleccionarHistorialPorMascota(int idMascota)
        {

            return historialDao.seleccionarHistorialPorMascota(idMascota);
        }

        // Agregar un nuevo historial médico
        [HttpPost("HistorialMedico")]
        public bool agregarHistorial([FromBody] HistorialMedico historial)
        {
            return historialDao.agregarHistorial(historial);
        }

        // Eliminar un historial médico por su ID
        [HttpDelete("HistorialMedico")]
        public bool eliminarHistorial(int id)
        {
            return historialDao.eliminarHistorial(id);
        }

        // Actualizar un historial médico existente
        [HttpPut("HistorialMedico")]
        public bool actualizarHistorial([FromBody] HistorialMedico historial)
        {
            return historialDao.actualizarHistorial(historial);
        }
    }
}
