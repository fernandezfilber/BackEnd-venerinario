﻿using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Web_Api.Controllers
{
    [Route("api")]
    [ApiController]
    public class EnfermedadController : ControllerBase
    {
        private EnfermedadDAO enfermedadDao = new EnfermedadDAO();

        
        // Obtener una enfermedad por ID
        [HttpGet("EnfermedadPorId")]
        public Enfermedad seleccionarPorId(int id)
        {
            return enfermedadDao.seleccionarPorId(id);
        }

        // Agregar una nueva enfermedad
        [HttpPost("Enfermedad")]
        public bool agregar([FromBody] Enfermedad enfermedad)
        {
            return enfermedadDao.agregar(enfermedad);
        }

        // Actualizar una enfermedad existente
        [HttpPut("Enfermedad")]
        public bool actualizar([FromBody] Enfermedad enfermedad)
        {
            return enfermedadDao.actualizar(enfermedad);
        }

        // Eliminar una enfermedad por ID
        [HttpDelete("Enfermedad")]
        public bool eliminar(int id)
        {
            return enfermedadDao.eliminar(id);
        }
    }

}
