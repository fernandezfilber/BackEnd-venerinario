﻿using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Web_Api.Services;

[Route("api")]
[ApiController]
public class DueñoController : ControllerBase
{
    private readonly DuenoServices _services;
    private readonly DueñoDAO dueñoDao;

    public DueñoController(DuenoServices services, DueñoDAO duenoDAO)
    {
        _services = services;
        dueñoDao = duenoDAO;
    }



    [HttpGet("Dueño*")]
    [Authorize(Roles = "Admin")] // Solo Admin puede ver un dueño por ID
    public Dueño seleccionarDueño(int id)
    {
        return dueñoDao.seleccionarDueños(id);
    }

    [HttpGet("DueñoPorNombreMascota")]
    [Authorize(Roles = "Admin")] // Solo Admin puede buscar por mascota
    public DueñoMascota obtenerDueñoPorNombreMascota(string nombreMascota)
    {
        return dueñoDao.seleccionarDueñoPorNombreMascota(nombreMascota);
    }

    [HttpGet("obtenerDueno")]
    [Authorize(Roles = "Admin, Veterinario")] // Admin y Veterinario pueden ver la lista de dueños
    public ActionResult<IEnumerable<Dueño>> GetDueños()
    {
        try
        {
            var dueños = dueñoDao.seleccionarTodos();
            return Ok(dueños);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Error: {ex.Message}");
            return StatusCode(500, "Error interno");
        }
    }

    [HttpPut("ActualizarDueno")]
    public async Task<IActionResult> ActualizarDueno(int id, [FromBody] DuenoDTO duenoDTO)
    {
        if (duenoDTO == null)
            return BadRequest(new { mensaje = "Datos inválidos." });

        bool actualizado = await _services.ActualizarDueno(id, duenoDTO);

        if (actualizado)
            return Ok(new { mensaje = "Dueño actualizado correctamente." });
        else
            return NotFound(new { mensaje = "No se pudo actualizar el dueño. Verifique los datos." });
    }


    [HttpPost("RegistroDueno")]
    public async Task<IActionResult> insertarDueno([FromBody] DuenoDTO dueno)
    {
        if (dueno == null || string.IsNullOrWhiteSpace(dueno.Nombre) || string.IsNullOrWhiteSpace(dueno.Correo))
            return BadRequest(new { mensaje = "Datos incompletos" });

        bool insertar = await _services.insertarDueno(dueno);

        if (insertar)
        {
            return Ok(new { exito = true, mensaje = "Dueño registrado" });
        }
        else
        {
            return BadRequest(new { exito = false, mensaje = "Error al registrar el dueño" });
        }
    }


    [HttpDelete("Dueno")]
    public async Task<bool> EliminarDueno(int id)
    {
        return await dueñoDao.eliminar(id);
    }

    [HttpGet("CantidadDuenos")]
    [AllowAnonymous]
    public IActionResult GetCantidadDuenos()
    {
        try
        {
            int cantidad = dueñoDao.seleccionarTodos().Count();
            return Ok(new { cantidad });
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Error: {ex.Message}");
            return StatusCode(500, "Error al obtener cantidad de dueños");
        }
    }






}

