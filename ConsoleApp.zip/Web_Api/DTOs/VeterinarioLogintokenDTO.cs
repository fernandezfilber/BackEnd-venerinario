﻿using AccesoVeterinaria.Models;

namespace Web_Api.DTOs
{
    public class VeterinarioLogintokenDTO
    {
        public AccesoVeterinaria.Models.Veterinario Usuario { get; set; } 
        public string Token { get; set; }
    }
}
