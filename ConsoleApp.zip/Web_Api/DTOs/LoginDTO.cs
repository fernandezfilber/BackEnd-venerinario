﻿using System.ComponentModel.DataAnnotations;

namespace Web_Api.DTOs
{
    public class LoginDTO
    {
        [Required(ErrorMessage = "campo Obligatorio")]
        public string Usuario { get; set; }=string.Empty;
        [Required(ErrorMessage = "campo Obligatorio")]
        public string Contrasena { get; set; } = string.Empty;
    }
}
