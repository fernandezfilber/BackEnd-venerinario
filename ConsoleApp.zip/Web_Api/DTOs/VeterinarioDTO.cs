﻿using AccesoVeterinaria.Models;
using System.Text.Json.Serialization;

public class VeterinarioDTO
{
    public string Usuario { get; set; } = string.Empty!;
    public string? Contrasena { get; set; } = string.Empty!;
    public string Nombre { get; set; } = string.Empty!;
    public string Telefono { get; set; } = string.Empty!;
    public string Correo { get; set; } = string.Empty!;
    public bool? Activo { get; set; }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public RolUsuario Rol { get; set; }
}

