﻿namespace Web_Api.DTOs
{
    public class Statistic
    {
        
        
            public string Label { get; set; }
            public int Value { get; set; }
        
    }
}
