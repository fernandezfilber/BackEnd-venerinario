﻿namespace Web_Api.DTOs
{
    public class ConsultaVeterianrioDTO
    {
        public int Id { get; set; } // Cambiado a int
        public string DetalleConsulta { get; set; }
        public string NombreMascota { get; set; }
        public string NombreVeterinario { get; set; }

    }
}
