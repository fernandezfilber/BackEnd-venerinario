﻿using AccesoVeterinaria.Models;

namespace Web_Api.DTOs
{
    public class ListaVetDTO
    {
        public int IdVeterinario { get; set; }
        public string Usuario { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public bool Activo { get; set; }
        public string Rol { get; set; }
    }
}
