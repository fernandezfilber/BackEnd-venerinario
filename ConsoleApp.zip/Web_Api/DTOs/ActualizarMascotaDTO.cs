﻿namespace Web_Api.DTOs
{
    public class ActualizarMascotaDTO
    {
        public string Nombre { get; set; }
        public string Especie { get; set; }
        public string Raza { get; set; }
        public int? Edad { get; set; }
        public string Sexo { get; set; }
        public int? IdDueño { get; set; }
    }
}
