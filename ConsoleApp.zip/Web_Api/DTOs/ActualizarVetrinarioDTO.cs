﻿using AccesoVeterinaria.Models;

namespace Web_Api.DTOs
{
    public class ActualizarVetrinarioDTO
    {
        public int IdVeterinario { get; set; }

        public string Usuario { get; set; } = null!;

        public string Contrasena { get; set; } = null!;

        public string? Nombre { get; set; }

        public string? Telefono { get; set; }

        public string? Correo { get; set; }

        public bool Activo { get; set; }

        public virtual ICollection<Consultum> Consulta { get; set; } = new List<Consultum>();
    }
}
