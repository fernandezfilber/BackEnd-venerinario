﻿namespace Web_Api.DTOs
{
    public class ActualizarPassDTO
    {
        public string usuario { get; set; }
        public string pass { get; set; }
        public string newpass { get; set; }
    }
}
