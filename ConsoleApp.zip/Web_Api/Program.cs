using AccesoVeterinaria.Context; // Add this using for your DbContext
using AccesoVeterinaria.Operations;
using Web_Api.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using AccesoVeterinaria.Models;
using Microsoft.OpenApi.Models;
using System.Text; // Add this using for UseSqlServer

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Register your DbContext
builder.Services.AddDbContext<BdVeterinariaContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))); // Assuming SQL Server and a connection string named "DefaultConnection" in appsettings.json

// Register your DAOs
builder.Services.AddScoped<ConsultumDAO>();
builder.Services.AddScoped<veterinarioDAO>();
builder.Services.AddScoped<Due�oDAO>();        //  Agregado
builder.Services.AddScoped<MascotaDAO>();      // Agregado
builder.Services.AddScoped<HistorialMedicoDAO>();
builder.Services.AddScoped<EnfermedadDAO>();
builder.Services.AddScoped<VacunaDAO>();


// Register your Services
builder.Services.AddScoped<VeterinarioServices>();
builder.Services.AddScoped<DuenoServices>();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
var key = builder.Configuration.GetValue<string>("ApiSettings:Secreta");
builder.Services.AddSwaggerGen(options =>

{

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme

    {

        Description =

        "Autenticaci�n JWT usando el esquema Bearer. <<\r\n\n" +

        "Ingresa la palabra 'Bearer' seguido de un espacio y despu�s su token en el campo de abajo.r\n\r\n" +

        "Ejemplo: \"Bearer adqweqdskdfl\"",

        Name = "Authorization",

        In = ParameterLocation.Header,

        Scheme = "Bearer"

    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement()

    {

        {

            new OpenApiSecurityScheme

            {

                Reference = new OpenApiReference

                {

                    Type = ReferenceType.SecurityScheme,

                    Id = "Bearer"

                },

                Scheme = "oauth2",

                Name = "Bearer",

                In = ParameterLocation.Header

            },

            new List<string>()

        }

    });

}

);

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("RequiereAdmin", policy =>
        policy.RequireClaim("RoleId", RolUsuario.Admin.ToString()));

    options.AddPolicy("RequiereOperador", policy =>
        policy.RequireClaim("RoleId", RolUsuario.Operador.ToString()));

    
    options.AddPolicy("RequiereVeterinario", policy =>
        policy.RequireClaim("RoleId", RolUsuario.Veterinario.ToString()));

    options.AddPolicy("ConsultasPermitidas", policy =>
        policy.RequireClaim("RoleId",
            RolUsuario.Admin.ToString(),
            RolUsuario.Veterinario.ToString(),
            RolUsuario.Operador.ToString()
        ));
});
builder.Services.AddAuthentication
    (
        x =>
        {
            x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        }
    ).AddJwtBearer
    (
        x =>
        {
            x.RequireHttpsMetadata = false;
            x.SaveToken = true;
            x.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(key)),
                ValidateIssuer = false,
                ValidateAudience = false
            };
        }
    );

//Agregar CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowViteFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:5173") // origen del frontend
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Usar CORS (antes de Authorization)
app.UseCors("AllowViteFrontend");

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
