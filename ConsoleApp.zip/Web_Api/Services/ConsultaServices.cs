﻿using AccesoVeterinaria.Context;
using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using Web_Api.DTOs;

namespace Web_Api.Services
{
    public class ConsultaServices
    {
        public class ConsultaService

        {
           
            
        }
    }
}
