﻿using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using Web_Api.DTOs;
using System.Collections.Generic; 
using System.Linq;    
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;         
namespace Web_Api.Services
{
    public class VeterinarioServices
    {
        private readonly veterinarioDAO _veterinarioDAO;
        private readonly ConsultumDAO _consultaDAO;
        private string claveSecreta;

        public VeterinarioServices(veterinarioDAO veterinarioDAO, ConsultumDAO consultaDAO, IConfiguration configuration)
        {
            _veterinarioDAO = veterinarioDAO;
            _consultaDAO = consultaDAO;
            claveSecreta = configuration.GetValue<string>("ApiSettings:Secreta");
        }

        public List<ListaVetDTO> ObtenerTodosLosVeterinarios() 
        {
        
            List<Veterinario> veterinariosDelDominio = _veterinarioDAO.seleccionarTodos();

      
            List<ListaVetDTO> veterinariosParaFrontend = veterinariosDelDominio
                .Select(v => new ListaVetDTO
                {
                    IdVeterinario = v.IdVeterinario,
                    Usuario = v.Usuario,
              
                    Nombre = v.Nombre,
                    Telefono = v.Telefono,
                    Correo = v.Correo,
                    Activo = v.Activo,
                    Rol = v.Rol.ToString()
                })
                .ToList();

            return veterinariosParaFrontend;
        }


        public async Task <bool> insertarVet(VeterinarioDTO veterinarioDTO)
        {
            var vet = new AccesoVeterinaria.Models.Veterinario
            {
                Usuario = veterinarioDTO.Usuario,
                Contrasena = veterinarioDTO.Contrasena,
                Nombre = veterinarioDTO.Nombre,
                Telefono = veterinarioDTO.Telefono,
                Correo = veterinarioDTO.Correo,
                Activo = veterinarioDTO.Activo.HasValue ? veterinarioDTO.Activo.Value : false,
                Rol = veterinarioDTO.Rol
            };
            return await  _veterinarioDAO.insertar(vet);
        }
        public async Task < bool> ActualizarVeterinario(int id, VeterinarioDTO veterinarioDTO)
        {
        
            var veterinarioParaActualizarDAO = new AccesoVeterinaria.Models.Veterinario
            {
                
                Usuario = veterinarioDTO.Usuario,
                Contrasena = veterinarioDTO.Contrasena, 
                Nombre = veterinarioDTO.Nombre,
                Telefono = veterinarioDTO.Telefono,
                Correo = veterinarioDTO.Correo,
               
                Activo = veterinarioDTO.Activo.HasValue ? veterinarioDTO.Activo.Value : false
            };


            bool exito = await _veterinarioDAO.actualizar(id, veterinarioParaActualizarDAO);

        
            return exito;
        }

        public async Task<VeterinarioLogintokenDTO?> login(LoginDTO? loginDT)
        {
            var vet = await _veterinarioDAO.login(loginDT.Usuario, loginDT.Contrasena);
            if (vet == null)
            {
                return null;
            }

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(claveSecreta);

            var claims = new List<Claim>
    {
        new Claim(ClaimTypes.Name, vet.Usuario),
    };

            
            if (vet.Rol.HasValue)
            {
                claims.Add(new Claim(ClaimTypes.Role, vet.Rol.Value.ToString()));
            }
            else
            {
                
            }

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims), 
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            return new VeterinarioLogintokenDTO
            {
                Usuario = vet,
                Token = tokenString
            };
        }
        public async Task<bool> actualizarPass(ActualizarPassDTO actualizarPassDTO)
        {
            var vet = await _veterinarioDAO.login(actualizarPassDTO.usuario, actualizarPassDTO.pass);
            if (vet == null)
            {
                return false;
            }
            return await _veterinarioDAO.actulizarPass(actualizarPassDTO.usuario, actualizarPassDTO.newpass);
        }

        public int GetMascotasRegistradas()
        {
            return _veterinarioDAO.GetMascotasRegistradas();
        }

        public int GetDuenosRegistrados()
        {
            return _veterinarioDAO.GetDuenosRegistrados();
        }

        public int GetVeterinariosActivos()
        {
            return _veterinarioDAO.GetVeterinariosActivos();
        }

        public int GetConsultasRealizadas()
        {
            return _veterinarioDAO.GetConsultasRealizadas();
        }

        public int GetVacunasAplicadas()
        {
            return _veterinarioDAO.GetVacunasAplicadas();
        }

        public int GetEnfermedadesComunes()
        {
            return _veterinarioDAO.GetEnfermedadesComunes();
        }

        public List<AccesoVeterinaria.Models.Statistic> GetChartStatistics()
        {
            try
            {
                return _veterinarioDAO.GetChartStatistics() ?? new List<AccesoVeterinaria.Models.Statistic>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching chart statistics: {ex.Message}");
                return new List<AccesoVeterinaria.Models.Statistic>();
            }
        }


        public async Task < bool> EliminarVeterinario(int idVeterinario)
        {
            try
            {
       
                var consultasAsociadas = _consultaDAO.ObtenerConsultasPorVeterinario(idVeterinario);

      
                foreach (var consulta in consultasAsociadas)
                {
                    bool consultaEliminada = _consultaDAO.eliminarConsulta(consulta.IdConsultas);
                    if (!consultaEliminada)
                    {
                        Console.WriteLine($"Advertencia: No se pudo eliminar la consulta con ID {consulta.IdConsultas} del vet {idVeterinario}.");
                      
                    }
                }

               
                return await _veterinarioDAO.eliminar(idVeterinario);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error en EliminarVeterinario para ID {idVeterinario}: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                }
                return false;
            }
        }
    }
}