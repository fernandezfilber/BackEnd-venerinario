﻿using AccesoVeterinaria.Models;
using AccesoVeterinaria.Operations;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Web_Api.Services
{
    public class DuenoServices
    {
        private readonly DueñoDAO _duenoDAO;
        private readonly MascotaDAO _mascotaDAO;

        public DuenoServices(DueñoDAO duenoDAO, MascotaDAO mascotaDAO)
        {
            _duenoDAO = duenoDAO;
            _mascotaDAO = mascotaDAO;
        }

        public List<Dueño> ObtenerTodosLosDuenos()
        {
            return _duenoDAO.seleccionarTodos();
        }

        public async Task<bool> insertarDueno(DuenoDTO duenoDTO)
        {
            var dueno = new AccesoVeterinaria.Models.Dueño
            {
                Nombre = duenoDTO.Nombre,
                Telefono = duenoDTO.Telefono,
                Direccion = duenoDTO.Direccion,
                Correo = duenoDTO.Correo
            };

            return await _duenoDAO.insertar(dueno);
        }


        public async Task<bool> ActualizarDueno(int id, DuenoDTO duenoDTO)
        {
            var duenoParaActualizarDAO = new AccesoVeterinaria.Models.Dueño
            {
                Nombre = duenoDTO.Nombre,
                Telefono = duenoDTO.Telefono,
                Direccion = duenoDTO.Direccion,
                Correo = duenoDTO.Correo
            };

            bool exito = await _duenoDAO.Actualizar(id, duenoParaActualizarDAO);
            return exito;
        }


        public async Task<bool> EliminarDueno(int idDueno)
        {
            try
            {
                // 1. Obtener las mascotas del dueño
                var mascotasAsociadas = _mascotaDAO.SeleccionarPorDueño(idDueno);

                foreach (var mascota in mascotasAsociadas)
                {
                    // 2. Eliminar cada mascota (esto incluye vacunas, consultas, historiales)
                    bool mascotaEliminada = _mascotaDAO.Eliminar(mascota.IdMascota);
                    if (!mascotaEliminada)
                    {
                        Console.WriteLine($"Advertencia: No se pudo eliminar la mascota con ID {mascota.IdMascota} del dueño {idDueno}.");
                    }
                }

                // 3. Eliminar el dueño
                return await _duenoDAO.eliminar(idDueno);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error en EliminarDueno para ID {idDueno}: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                }
                return false;
            }
        }



    }
}
